import express from "express";
import bodyParser from "body-parser";
import pg from "pg";

const app = express();
const port = 3000;

const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "world",
  password: "110594",
  port: 1154,
});
db.connect();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

let currentUserId = 1;

let users = [
  { id: 1, name: "Angela", color: "teal" },
  { id: 2, name: "Jack", color: "powderblue" },
];

async function checkVisited() {
  try {
    const result = await db.query("SELECT country_code FROM visited_countries JOIN users ON users.id=user_id WHERE user_id=$1;", [currentUserId]);
    return result.rows.map(country => country.country_code);
  } catch (err) {
    console.error(err);
    return [];
  }
}

async function getCurrentUser() {
  try {
    const result = await db.query("SELECT * FROM users");
    users = result.rows;
    return users.find(user => user.id == currentUserId);
  } catch (err) {
    console.error(err);
    return null;
  }
}

app.get("/", async (req, res) => {
  const countries = await checkVisited();
  const currentUser = await getCurrentUser();
  if (currentUser) {
    res.render("index.ejs", {
      countries: countries,
      total: countries.length,
      users: users,
      color: currentUser.color,
    });
  } else {
    res.status(500).send("Error fetching current user.");
  }
});

app.post("/add", async (req, res) => {
  const input = req.body["country"];
  if (!input) {
    return res.redirect("/");
  }

  try {
    const currentUser = await getCurrentUser();
    const result = await db.query("SELECT country_code FROM countries WHERE LOWER(country_name) LIKE '%' || $1 || '%';", [input.toLowerCase()]);
    const data = result.rows[0];
    if (data) {
      const countryCode = data.country_code;

      // Check if the country is already visited by the user
      const checkResult = await db.query("SELECT * FROM visited_countries WHERE country_code=$1 AND user_id=$2;", [countryCode, currentUserId]);
      if (checkResult.rows.length === 0) {
        // If not, insert the country
        await db.query("INSERT INTO visited_countries (country_code, user_id) VALUES ($1, $2)", [countryCode, currentUserId]);
      }
    }
    res.redirect("/");
  } catch (err) {
    console.error(err);
    res.redirect("/");
  }
});

app.post("/user", async (req, res) => {
  if (req.body.add === "new") {
    res.render("new.ejs");
  } else {
    currentUserId = req.body.user;
    res.redirect("/");
  }
});

app.post("/new", async (req, res) => {
  const name = req.body.name;
  let color = req.body.color || "black"; // Default color to black if not provided

  try {
    const result = await db.query("INSERT INTO users (name, color) VALUES ($1, $2) RETURNING *;", [name, color]);
    currentUserId = result.rows[0].id;
    res.redirect("/");
  } catch (err) {
    console.error(err);
    res.status(500).send("Error creating new user.");
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
